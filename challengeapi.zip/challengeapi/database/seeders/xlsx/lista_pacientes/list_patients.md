list_patients
=============

| #  |               NOME               | DATA DE NASCIMENTO |   TELEFONE   | TEM COMORBIDADES? | JÁ FOI VACINADO CONTRA A COVID 19 |   |   |
|----|----------------------------------|--------------------|--------------|-------------------|------------------------------------|---|---|
| 1  | Maria Joaquina de Mendonça      | 18068              | 21 6322-5698 | SIM               | SIM                                |   |   |
| 2  | Otávio de Oliveira Pinto        | 27364              | 21 6699-8822 | NÃO              | SIM                                |   |   |
| 3  | Aloísio Malta de Alencar Macedo | 24342              | 21 6107-8022 | SIM               | SIM                                |   |   |
| 4  | Aline Nepomuceno Costa e Silva   | 37110              | 21 6988-0356 | NÃO              | NÃO                               |   |   |
| 5  | Rosemary Azevedo Lins da Silva   | 29550              | 21 6771-4540 | SIM               | NÃO                               |   |   |
| 6  | Henrique Moreira Salas           | 33854              | 21 7915-7885 | NÃO              | NÃO                               |   |   |
| 7  | Rorberto Casemiro Almeida Nunes  | 25699              | 21 7374-7403 | SIM               | SIM                                |   |   |
| 8  | Enzo Rossi Matarazzo             | 37680              | 21 7778-2325 | NÃO              | NÃO                               |   |   |
| 9  | Mayla Zimmer Rockenbach          | 32584              | 21 7152-8963 | NÃO              | NÃO                               |   |   |
| 10 | Alice dos Santos Oliveira        | 20460              | 21 7215-4157 | NÃO              | SIM                                |   |   |
(10 rows)

